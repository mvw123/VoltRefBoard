Voltage Calibration Board
=========================

Reference board for calibration of Voltage.

CAD A - [PCB ordered]
=====================

PCB fabrication ordered from OSH park
Need to setup parts for ordering
2.5v and 5.0v voltage reference source from a 9v battery or from an external power source.


